/*
 * ssd1306_test.h
 *
 *  Created on: Jan 30, 2020
 *      Author: 20004719
 */

#ifndef INC_SSD1306_TEST_H_
#define INC_SSD1306_TEST_H_

void ssd1306_TestBorder();
void ssd1306_TestFonts();
void ssd1306_TestFPS();
void ssd1306_TestAll();

#endif /* INC_SSD1306_TEST_H_ */
