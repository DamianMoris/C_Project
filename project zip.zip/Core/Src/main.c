/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include <ssd1306.h>
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SSD1306_USE_I2C
#define __DEBUG 1
#define BUFFERSIZE 100
#define I2CBUF	12
#define debug_print(x) 	do { if ( __DEBUG ) { strcpy(uartBuffer, x); HAL_UART_Transmit(&huart2, (unsigned char*) uartBuffer, strlen(uartBuffer), HAL_MAX_DELAY); }} while (0)
#define ROCKET_POS_1 13 //bovenste Y positie van de raket
#define ROCKET_POS_2 24 //
#define ROCKET_POS_3 35 //middelste Y positie van de raket
#define ROCKET_POS_4 46 //
#define ROCKET_POS_5 57 //onderste Y positie van de raket
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
const uint8_t SSD1306_ADDRESS = 0x3C << 1;
const uint8_t RANDOM_REG = 0x0F;

char uartBuffer[BUFFERSIZE] = "";
uint8_t I2CBuffer[I2CBUF] = {0};
HAL_StatusTypeDef returnValue = 0;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);


/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void PrintScore();
void PrintExplosie();
void EndScreen();

typedef struct{
	int meteorX;
	int meteorY;
}meteors;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */

int main(void)
{
	/* USER CODE BEGIN 1 */
	meteors meteor1, meteor2, meteor3, meteor4;
	int score = 0;
	int rocketX = 5;
	int rocketY = ROCKET_POS_3;
	int meteorPosition[] = {ROCKET_POS_1, ROCKET_POS_2, ROCKET_POS_3, ROCKET_POS_4, ROCKET_POS_5};
	/* USER CODE END 1 */


	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART2_UART_Init();
	MX_I2C1_Init();
	/* USER CODE BEGIN 2 */

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	debug_print("Hello from STM32L432KC dev board\r\n");
	ssd1306_Init();
	srand(time(NULL));
	ssd1306_Fill(Black);
	while(1){
		while(1){

			// om het veelvoud van 128 van de scoren worden er een random aantal meteoren geprint
			if(score % 32 == 0){

				meteor1.meteorY = meteorPosition[rand() % 5 ];
				do{meteor2.meteorY = meteorPosition[rand() % 5 ];}while(meteor1.meteorY == meteor2.meteorY);
				do{meteor3.meteorY = meteorPosition[rand() % 5 ];}while(meteor1.meteorY == meteor3.meteorY || meteor2.meteorY == meteor3.meteorY);
				do{meteor4.meteorY = meteorPosition[rand() % 5 ];}while(meteor1.meteorY == meteor4.meteorY || meteor2.meteorY == meteor4.meteorY || meteor3.meteorY == meteor4.meteorY);

				meteor1.meteorX = 128;
				meteor2.meteorX = 128;
				meteor3.meteorX = 128;
				meteor4.meteorX = 128;
			}

			//score printen
			PrintScore(&score);

			//raket printen
			ssd1306_SetCursor(rocketX, rocketY);
			ssd1306_WriteString(" ", Raket, White);

			//print 4 meteoren p random posities en beweegt ze naar links
			if(meteor1.meteorX != 0 && meteor2.meteorX != 0 && meteor3.meteorX != 0 && meteor4.meteorX != 0){
				meteor1.meteorX -= 4;
				ssd1306_SetCursor(meteor1.meteorX, meteor1.meteorY);
				ssd1306_WriteString(" ", Meteor, White);
				meteor2.meteorX -= 4;
				ssd1306_SetCursor(meteor2.meteorX, meteor2.meteorY);
				ssd1306_WriteString(" ", Meteor, White);
				meteor3.meteorX -= 4;
				ssd1306_SetCursor(meteor3.meteorX, meteor3.meteorY);
				ssd1306_WriteString(" ", Meteor, White);
				meteor4.meteorX -= 4;
				ssd1306_SetCursor(meteor4.meteorX, meteor4.meteorY);
				ssd1306_WriteString(" ", Meteor, White);
			}

			//als de score minder is dan 500 dan word de positie van de raket berekend en uitgevoerd om de meteoren te ontwijken
			//als de score meer is dan 500 dan blijft de positie onveranderd en is de kans groot dat de raket tegen de meteoren gaat stoten(wat de bedoeling is)
			if(score < 500){
				if(meteor1.meteorY != ROCKET_POS_1 && meteor2.meteorY != ROCKET_POS_1 && meteor3.meteorY != ROCKET_POS_1 && meteor4.meteorY != ROCKET_POS_1){
				  if(rocketY != ROCKET_POS_1){
					  if(rocketY == ROCKET_POS_2){rocketY = ROCKET_POS_1;}
					  else if(rocketY == ROCKET_POS_3){rocketY = ROCKET_POS_2;}
					  else if(rocketY == ROCKET_POS_4){rocketY = ROCKET_POS_3;}
					  else if(rocketY == ROCKET_POS_5){rocketY = ROCKET_POS_4;}
				  }
				}
				else if(meteor1.meteorY != ROCKET_POS_2 && meteor2.meteorY != ROCKET_POS_2 && meteor3.meteorY != ROCKET_POS_2 && meteor4.meteorY != ROCKET_POS_2){
				  if(rocketY != ROCKET_POS_2){
					  if(rocketY == ROCKET_POS_1){rocketY = ROCKET_POS_2;}
					  else if(rocketY == ROCKET_POS_3){rocketY = ROCKET_POS_2;}
					  else if(rocketY == ROCKET_POS_4){rocketY = ROCKET_POS_3;}
					  else if(rocketY == ROCKET_POS_5){rocketY = ROCKET_POS_4;}
				  }
				}
				else if(meteor1.meteorY != ROCKET_POS_3 && meteor2.meteorY != ROCKET_POS_3 && meteor3.meteorY != ROCKET_POS_3 && meteor4.meteorY != ROCKET_POS_3){
				  if(rocketY != ROCKET_POS_3){
					  if(rocketY == ROCKET_POS_1){rocketY = ROCKET_POS_2;}
					  else if(rocketY == ROCKET_POS_2){rocketY = ROCKET_POS_3;}
					  else if(rocketY == ROCKET_POS_4){rocketY = ROCKET_POS_3;}
					  else if(rocketY == ROCKET_POS_5){rocketY = ROCKET_POS_4;}
				  }
				}
				else if(meteor1.meteorY != ROCKET_POS_4 && meteor2.meteorY != ROCKET_POS_4 && meteor3.meteorY != ROCKET_POS_4 && meteor4.meteorY != ROCKET_POS_4){
				  if(rocketY != ROCKET_POS_4){
					  if(rocketY == ROCKET_POS_1){rocketY = ROCKET_POS_2;}
					  else if(rocketY == ROCKET_POS_2){rocketY = ROCKET_POS_3;}
					  else if(rocketY == ROCKET_POS_3){rocketY = ROCKET_POS_4;}
					  else if(rocketY == ROCKET_POS_5){rocketY = ROCKET_POS_4;}
				  }
				}
				else if(meteor1.meteorY != ROCKET_POS_5 && meteor2.meteorY != ROCKET_POS_5 && meteor3.meteorY != ROCKET_POS_5 && meteor4.meteorY != ROCKET_POS_5){
				  if(rocketY != ROCKET_POS_5){
					  if(rocketY == ROCKET_POS_1){rocketY = ROCKET_POS_2;}
					  else if(rocketY == ROCKET_POS_2){rocketY = ROCKET_POS_3;}
					  else if(rocketY == ROCKET_POS_3){rocketY = ROCKET_POS_4;}
					  else if(rocketY == ROCKET_POS_4){rocketY = ROCKET_POS_5;}
				  }
				}
			}

			//als de raket en meteor elkaar raken dan dan word er een explosie geprint, en gaat uit de while waardat de endscreen word geprint
			if((rocketY == meteor1.meteorY || rocketY == meteor2.meteorY || rocketY == meteor3.meteorY || rocketY == meteor4.meteorY) && (rocketX >= meteor1.meteorX || rocketX >= meteor2.meteorX || rocketX >= meteor3.meteorX || rocketX >= meteor4.meteorX)){
			PrintExplosie(rocketX, rocketY-3);
			HAL_Delay(800);
			ssd1306_Fill(Black);
			break;
			}
		ssd1306_UpdateScreen();
		ssd1306_Fill(Black);
		HAL_Delay(20);
		}
		//print het eindscherm en gaat dan terug in de while
		EndScreen(&score);
	}
}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure LSE Drive Capability 
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 16;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the main internal regulator output voltage 
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enable MSI Auto calibration 
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00707CBB;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter 
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter 
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LD3_Pin */
  GPIO_InitStruct.Pin = LD3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD3_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void PrintScore(int *ptrScore){
	char scoreArr[5];
	ssd1306_SetCursor(34, 0);
	ssd1306_WriteString("Score:", Font_6x8, White);
	itoa(*ptrScore, scoreArr, 10);
	ssd1306_WriteString(scoreArr, Font_6x8, White);
	(*ptrScore)++;
}

void PrintExplosie(int xpos, int ypos){
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString(" ", Explosie, White);
    ssd1306_UpdateScreen();
    HAL_Delay(100);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString(" ", Explosie, Black);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("!", Explosie, White);
    ssd1306_UpdateScreen();
    HAL_Delay(100);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("!", Explosie, Black);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("#", Explosie, White);
    ssd1306_UpdateScreen();
    HAL_Delay(100);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("#", Explosie, Black);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("$", Explosie, White);
    ssd1306_UpdateScreen();
    HAL_Delay(100);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("$", Explosie, Black);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("%", Explosie, White);
    ssd1306_UpdateScreen();
    HAL_Delay(100);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("%", Explosie, Black);
    ssd1306_SetCursor(xpos, ypos);
    ssd1306_WriteString("&", Explosie, White);
    ssd1306_UpdateScreen();
}

void EndScreen(int *endscore){
	char scoreArr[5];
	ssd1306_SetCursor(14, 10);
	ssd1306_WriteString("GAME OVER", Font_11x18, White);
	ssd1306_SetCursor(34, 40);
	ssd1306_WriteString("Score:", Font_6x8, White);
	itoa(*endscore, scoreArr, 10);
	ssd1306_WriteString(scoreArr, Font_6x8, White);

	*endscore = 0;

	ssd1306_UpdateScreen();
	HAL_Delay(4000);
	ssd1306_Fill(Black);
	for(int i = 0; i < 7; i++){
		ssd1306_SetCursor(30, 28);
		ssd1306_Fill(Black);
		ssd1306_WriteString("Restarting", Font_6x8, White);
		HAL_Delay(100);
		ssd1306_UpdateScreen();
		ssd1306_SetCursor(30, 28);
		ssd1306_Fill(Black);
		ssd1306_WriteString("Restarting.", Font_6x8, White);
		HAL_Delay(100);
		ssd1306_UpdateScreen();
		ssd1306_SetCursor(30, 28);
		ssd1306_Fill(Black);
		ssd1306_WriteString("Restarting..", Font_6x8, White);
		HAL_Delay(100);
		ssd1306_UpdateScreen();
		ssd1306_SetCursor(30, 28);
		ssd1306_Fill(Black);
		ssd1306_WriteString("Restarting...", Font_6x8, White);
		HAL_Delay(100);
		ssd1306_UpdateScreen();
	}
	ssd1306_Fill(Black);
	HAL_Delay(500);
	ssd1306_UpdateScreen();
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
